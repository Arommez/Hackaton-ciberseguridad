public class Usuario {
    static String nombre, apellidos, curp, domicilio, correo, clave, fechanacimiento;

    public static void RegistroCuenta(String nom, String ape, String fech, String cur, String corr, String domi, String clav){
        nombre = nom;
        apellidos = ape;
        fechanacimiento = fech;
        curp = cur;
        correo = corr;
        domicilio = domi;
        clave = clav;
    }
    public static String getNombre (){
        return nombre;
    }
    public static String getApellido(){
        return apellidos;
    }
    public static String getNacimiento(){
        return fechanacimiento;

    }
    public static String getCURP(){
        return curp;
    }
    public static String Correo(){
        return correo;
    }
    public static String Domicilio() {
        return domicilio;
    }
}
