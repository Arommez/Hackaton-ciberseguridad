public class Reportes {
    //Esta clase almacenara la ubicacion del usuario, mandando un reporte con la ubicacion y la id del usuario a una base e datos SQL.


}
