public class Login {
    String Usuario;
    String clave;
    public static void setUsuario(String usuarioEn){


    }
}
